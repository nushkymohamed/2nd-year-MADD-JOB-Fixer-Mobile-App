package com.firstapp.jobfixer.Model;

public class Resume {

    private String userId ;
    private String ResId ;
    private String firstName;
    private String LastName;
    private String location;
    private String phone;
    private String email;
    private String job;
    private String JobCat;
    private String JobTit;
    private String aboutMe;
    private String workExp;
    private String education;

    public Resume(){
    }

    public Resume(String userId, String resId, String firstName, String lastName, String location, String phone, String email, String job, String jobCat, String jobTit, String aboutMe, String workExp, String education) {
        this.userId = userId;
        ResId = resId;
        this.firstName = firstName;
        LastName = lastName;
        this.location = location;
        this.phone = phone;
        this.email = email;
        this.job = job;
        JobCat = jobCat;
        JobTit = jobTit;
        this.aboutMe = aboutMe;
        this.workExp = workExp;
        this.education = education;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getResId() {
        return ResId;
    }

    public void setResId(String resId) {
        ResId = resId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getJobCat() {
        return JobCat;
    }

    public void setJobCat(String jobCat) {
        JobCat = jobCat;
    }

    public String getJobTit() {
        return JobTit;
    }

    public void setJobTit(String jobTit) {
        JobTit = jobTit;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public String getWorkExp() {
        return workExp;
    }

    public void setWorkExp(String workExp) {
        this.workExp = workExp;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }
}
