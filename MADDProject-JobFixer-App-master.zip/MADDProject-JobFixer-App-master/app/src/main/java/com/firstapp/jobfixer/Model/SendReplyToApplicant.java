package com.firstapp.jobfixer.Model;

public class SendReplyToApplicant {

    private String userID;
    private String jobName;
    private String compName;
    private String compEmail;
    private String sendDate;
    private String applicantName;
    private String applicantEmail;
    private String compMsg;

    public SendReplyToApplicant(){}

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getCompEmail() {
        return compEmail;
    }

    public void setCompEmail(String compEmail) {
        this.compEmail = compEmail;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getApplicantEmail() {
        return applicantEmail;
    }

    public void setApplicantEmail(String applicantEmail) {
        this.applicantEmail = applicantEmail;
    }

    public String getCompMsg() {
        return compMsg;
    }

    public void setCompMsg(String compMsg) {
        this.compMsg = compMsg;
    }
}
